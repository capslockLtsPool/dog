#!/bin/bash
runDir=`pwd`
scriptDir=`dirname $0`
cd $scriptDir
echo "This script is used to remove ApacheSafeDog!"
read -p "Are you sure to remove ApacheSafeDog?[y/n]" remove
if [ $remove != y ];then
	exit 0
fi
killall sdalog>/dev/null 2>&1
killall sdacm>/dev/null 2>&1
echo "please wait..."
sdauduninstall NF-7400LP

rm -f /etc/rc2.d/S99sdaboot
rm -f /etc/rc3.d/S99sdaboot
rm -f /etc/rc4.d/S99sdaboot
rm -f /etc/rc5.d/S99sdaboot
rm -f /etc/rc6.d/S99sdaboot
rm -f /etc/init.d/sdaboot
rm -f /usr/bin/sdaboot
rm -f /usr/bin/sdacm
rm -f /usr/bin/sdalog
rm -f /usr/bin/sdaudinstall
rm -f /usr/bin/sdauduninstall
echo "remove bin ok!"

chattr -i /usr/lib64/libapache_safedog_2_2_64.so.0.0.0
rm -f /usr/lib64/libapache_safedog_2_2_64.so.0.0.0
rm -f /usr/lib64/libapache_safedog_2_2_64.so
chattr -i /usr/lib64/libSPModule_64.so.0.0.0
rm -f /usr/lib64/libSPModule_64.so.0.0.0
rm -f /usr/lib64/libSPModule_64.so
chattr -i /usr/lib64/libWPCPlugin_64.so.0.0.0
rm -f /usr/lib64/libWPCPlugin_64.so.0.0.0
rm -f /usr/lib64/libWPCPlugin_64.so
echo "remove library ok!"

installdir=`grep ApacheSafeDogInstallDir /etc/apachesd.conf`
installdir=${installdir#*ApacheSafeDogInstallDir=}
if [ -d $installdir ];then
	rm -rf $installdir/Analysis
	rm -rf $installdir/conf
	rm -rf $installdir/GeneralConfig
	rm -f $installdir/SafeDogSiteApacheFilter.Conf
	echo "remove apache safe dog's install directory ok!"
fi
apconf=`grep ApacheConfPath /etc/apachesd.conf`
apconf=${apconf#*ApacheConfPath=}
if [ -f $apconf ];then
	delstr="#Begin SafeDogSite-ApacheFilter edits - remove only on uninstall"	
	sed -i "s/$delstr//g" $apconf
	sdconf=`grep SafeDogConfPath /etc/apachesd.conf`
	sdconf=${sdconf#*SafeDogConfPath=}
	sdconf=${sdconf//\//\\\/}
	sed -i "s/Include \"$sdconf\"//g" $apconf
fi
echo "remove load information in apache ok!"

logdir=/var/log/apachesd
if [ -d $logdir ];then
	rm -rf $logdir
	echo "remove log ok!"
fi
conf=/etc/apachesd.conf
if [ -f $conf ];then
	rm -f $conf
	echo "remove configure file ok!"
fi
echo "romove done!"
echo "please restart apache server!"
echo

